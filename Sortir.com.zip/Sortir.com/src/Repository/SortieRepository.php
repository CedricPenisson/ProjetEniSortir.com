<?php

namespace App\Repository;

use App\Data\FiltrerSorties;
use App\Entity\Participant;
use App\Entity\Sortie;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;


/**
 * @method Sortie|null find($id, $lockMode = null, $lockVersion = null)
 * @method Sortie|null findOneBy(array $criteria, array $orderBy = null)
 * @method Sortie[]    findAll()
 * @method Sortie[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class SortieRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Sortie::class);
    }

    // Création de la méthode pour afficher les sorties avec les filtres choisis
    public function findFiltresSorties( FiltrerSorties $filtreSortie, Participant $user)
    {

        $queryBuilder = $this->createQueryBuilder('s');

        $queryBuilder->andWhere('s.dateHeureDebut > :now')
            ->setParameter('now', new \DateTime("now - 1 month"));

        // Filtre sur les campus
        if(!empty($filtreSortie->campus)){
            $queryBuilder ->andWhere('s.campus = :campus')
                ->setParameter('campus', $filtreSortie->campus);
        }
        // Filtre sur la recherche par terme
        if(!empty($filtreSortie->recherche)){
            $queryBuilder ->andWhere('s.nom LIKE :recherche')
                ->setParameter('recherche', "%{$filtreSortie->recherche}%");
        }
        // Filtre sur les dates
        if(!empty($filtreSortie->dateDebut)){
            $queryBuilder ->andWhere('s.dateHeureDebut >= :dateDebut')
                ->setParameter('dateDebut', $filtreSortie->dateDebut);
        }
        // Filtre sur les dates
        if(!empty($filtreSortie->dateFin)){
            $queryBuilder ->andWhere('s.dateHeureDebut <= :dateFin')
                ->setParameter('dateFin', $filtreSortie->dateFin);
        }
        // Filtre pour les sorties organisées par l'utilsateur
        if(!empty($filtreSortie->sortiesOrganisees)) {
                $queryBuilder->andWhere('s.organisateur = :sortiesOrganisees')
                    ->setParameter('sortiesOrganisees', $user->getId());
        }
        // Filtre sur les sorties où l'utilisateur est inscrit
        if(!empty($filtreSortie->sortiesInscrites)) {
            $queryBuilder->andWhere(':sortiesInscrites MEMBER OF s.inscrits')
                ->setParameter('sortiesInscrites', $user->getId());
        }
        // Filtre sur les sorties où l'utilisateur n'est pas inscrit
        if(!empty($filtreSortie->sortiesNonInscrites)) {
            $queryBuilder->andWhere(':sortiesNonInscrites  NOT MEMBER OF s.inscrits')
                ->setParameter('sortiesNonInscrites', $user->getId());
        }
        // Filtre sur les sorties passées
        if(!empty($filtreSortie->sortiesPassees)) {
            $dateJour = new \DateTime('now');
            $queryBuilder->andWhere(':dateJour > s.dateHeureDebut')
                ->setParameter('dateJour', $dateJour);
        }

        $query = $queryBuilder->getQuery();

        return $query->execute();
    }
}
