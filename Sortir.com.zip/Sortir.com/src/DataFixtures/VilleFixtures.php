<?php

namespace App\DataFixtures;

use App\Entity\Ville;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;
use Faker\Factory;

class VilleFixtures extends Fixture
{
    public function load(ObjectManager $manager)
    {
        $faker = Factory::create('fr FR');

        for ($i=0; $i<=10; $i++) {

            //Création d'une ville
            $ville = new Ville();

            $ville->setNom($faker->city());
            $ville->setCodePostal($faker->postcode());
            $manager->persist($ville);
            $this->addReference(Ville::class.$i, $ville);
        }


        $manager->flush();
    }

    /*        //Création d'un participant
        $ville = new Ville();
        $i = 0;

        $ville -> setNom('NOIRMOUTIER');
        $ville->setCodePostal(85630);
        $manager    -> persist($ville);
        $this -> addReference(Ville::class.$i, $ville);
        $i +=1;

        $ville = new Ville();
        $ville -> setNom('BELLE ILE EN MER');
        $ville->setCodePostal(56360);
        $manager    -> persist($ville);
        $this -> addReference(Ville::class.$i, $ville);
        $i +=1;

        $ville = new Ville();
        $ville -> setNom('SAINT MALO');
        $ville->setCodePostal(35400);
        $manager    -> persist($ville);
        $this -> addReference(Ville::class.$i, $ville);*/

}
