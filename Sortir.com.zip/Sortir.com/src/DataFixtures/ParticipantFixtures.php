<?php

namespace App\DataFixtures;

use App\Entity\Campus;
use App\Entity\Participant;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Common\DataFixtures\DependentFixtureInterface;
use Doctrine\Persistence\ObjectManager;
use Faker\Factory;
use Symfony\Component\Security\Core\Encoder\UserPasswordEncoderInterface;

class ParticipantFixtures extends Fixture implements DependentFixtureInterface
{
    private $passwordEncoder;
    public function __construct(UserPasswordEncoderInterface $passwordEncoder)
    {
        $this->passwordEncoder = $passwordEncoder;
    }

    public function load(ObjectManager $manager)
    {
        // Utilisation du faker
        $faker = Factory::create('fr FR');
        //Création d'un participant

        for ($i=0; $i<=30; $i++) {
            $user = new Participant();

            $user->setNom($faker->unique()->lastName())
                ->setPrenom($faker->firstName())
                ->setTelephone($faker->phoneNumber())
                ->setMail(strtolower(substr($user->getPrenom(),0,1).$user->getNom()).'@eni.fr')
                ->setPseudo(    strtolower(substr($user->getPrenom(),0,1).$user->getNom()))
                ->setIsAdministrateur(false)
                ->setisActif(true)
                ->setCampus($this->getReference(Campus::class.mt_rand(0,2))) // Récupère l'objet
                ->setPhoto('tof'.($i+1).'.jpg');

            $plainPassword = 'password';
            $user->setPassword(
                $this->passwordEncoder->encodePassword(
                    $user, $plainPassword)
            );

            $manager->persist($user);
            $this->addReference(Participant::class.$i, $user);

        }
        // $product = new Product();
        // $manager->persist($product);

        $manager->flush();
    }
    // implémenter dans le cas d'une fixture avec getReference()
    public function getDependencies()
    {
        return [
            CampusFixtures::class
        ];
    }
}
