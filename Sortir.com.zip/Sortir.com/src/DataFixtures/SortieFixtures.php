<?php

namespace App\DataFixtures;

use App\Entity\Campus;
use App\Entity\Etat;
use App\Entity\Lieu;
use App\Entity\Participant;
use App\Entity\Sortie;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Common\DataFixtures\DependentFixtureInterface;
use Doctrine\Persistence\ObjectManager;
use Faker\Factory;

class SortieFixtures extends Fixture implements DependentFixtureInterface
{
    public function load(ObjectManager $manager)
    {
        // Utilisation du faker
        $faker = Factory::create('fr FR');

        // Création d'une sortie
        for ($i=1; $i<25; $i++ ){
            $sortie = new Sortie();

            $sortie->setNom($faker->word());
            $sortie->setDateHeureDebut($faker->dateTimeBetween('now + 2 days', '3 months'));
            $sortie->setDuree($faker->numberBetween(30,240));
            $sortie->setDateLimiteInscription($faker->dateTimeBetween('-1 month', 'now + 7 hours'));
            $sortie->setNbInscriptionsMax($faker->numberBetween(2, 40));
            $sortie->setInfosSortie($faker->text(300));
            $sortie->setLieu($this->getReference(Lieu::class.mt_rand(0,10)));
            $sortie->setEtat($this->getReference(Etat::class.mt_rand(0,5)));
            $sortie->setCampus($this->getReference(Campus::class.mt_rand(0,2)));
            $sortie->setOrganisateur($this->getReference(Participant::class.mt_rand(0,10)));


            for ($j=0; $j<($sortie->getNbInscriptionsMax())-(mt_rand(0,$sortie->getNbInscriptionsMax())); $j++)
            {
                $sortie->addInscrit($this->getReference(Participant::class.mt_rand(0,10)));
            }

            $manager->persist($sortie);
        }

        $manager->flush();
    }

    public function getDependencies()
    {
        return [
            LieuFixtures::class,
            EtatFixtures::class,
            ParticipantFixtures::class
        ];
    }
}
