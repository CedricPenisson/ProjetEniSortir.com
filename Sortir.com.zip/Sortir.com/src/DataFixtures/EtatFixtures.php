<?php

namespace App\DataFixtures;

use App\Entity\Etat;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;

class EtatFixtures extends Fixture
{
    public function load(ObjectManager $manager)
    {
        //Création d'un état
        $etat = new Etat();
        $i=0;

        $etat->setLibelle('Créée');
        $manager->persist($etat);
        $this->addReference(Etat::class.$i, $etat);
        $i +=1;

        $etat = new Etat();
        $etat->setLibelle('Ouverte');
        $manager->persist($etat);
        $this->addReference(Etat::class.$i, $etat);
        $i +=1;

        $etat = new Etat();
        $etat->setLibelle('Clôturée');
        $manager->persist($etat);
        $this->addReference(Etat::class.$i, $etat);
        $i +=1;

        $etat = new Etat();
        $etat->setLibelle('Activité en cours');
        $manager->persist($etat);
        $this->addReference(Etat::class.$i, $etat);
        $i +=1;

        $etat = new Etat();
        $etat->setLibelle('Passée');
        $manager->persist($etat);
        $this->addReference(Etat::class.$i, $etat);
        $i +=1;

        $etat = new Etat();
        $etat->setLibelle('Annulée');
        $manager->persist($etat);
        $this->addReference(Etat::class.$i, $etat);
        $i +=1;

        $manager->flush();
    }
}
