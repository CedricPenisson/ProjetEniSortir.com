<?php

namespace App\DataFixtures;

use App\Entity\Campus;

use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;

class CampusFixtures extends Fixture
{

    public function load(ObjectManager $manager)
    {
        //Création d'un participant
        $campus = new Campus();
        $i = 0;

        $campus -> setNom('SAINT HERBLAIN');
        $manager    -> persist($campus);
        $this -> addReference(
            Campus::class.$i, $campus);
        $i +=1;

        $campus = new Campus();
        $campus -> setNom('CHARTRES DE BRETAGNE');
        $manager    -> persist($campus);
        $this -> addReference(
            Campus::class.$i, $campus);
        $i +=1;

        $campus = new Campus();
        $campus -> setNom('LA ROCHE SUR YON');
        $manager    -> persist($campus);
        $this -> addReference(
            Campus::class.$i, $campus);


        // $product = new Product();
        // $manager->persist($product);

        $manager->flush();
    }


}
