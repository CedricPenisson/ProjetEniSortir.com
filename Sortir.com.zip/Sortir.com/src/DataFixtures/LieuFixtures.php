<?php

namespace App\DataFixtures;

use App\Entity\Lieu;
use App\Entity\Ville;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Common\DataFixtures\DependentFixtureInterface;
use Doctrine\Persistence\ObjectManager;
use Faker\Factory;

class LieuFixtures extends Fixture implements DependentFixtureInterface
{
    public function load(ObjectManager $manager)
    {
        $faker = Factory::create('fr FR');

        for ($i=0; $i<=50; $i++) {
            //Création d'un lieu
            $lieu = new Lieu();

            $lieu->setNom($faker->word);
            $lieu->setRue($faker->address());
            $lieu->setLatitude($faker->latitude);
            $lieu->setLongitude($faker->longitude);
            $lieu->setVille($this->getReference(Ville::class.mt_rand(0,2)));
            $this->addReference(Lieu::class.$i, $lieu);

            $manager->persist($lieu);

            // $product = new Product();
            // $manager->persist($product);
        }
        $manager->flush();
    }

    public function getDependencies()
    {
        return [
            VilleFixtures::class
        ];
    }
}
