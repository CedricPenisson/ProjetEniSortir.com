<?php

namespace App\Form;

use App\Entity\Lieu;
use App\Entity\Sortie;
use App\Entity\Ville;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\TextType;



class SortieType extends AbstractType
{
    /**
     * @var EntityManagerInterface
     */
    private $em;

    public function __construct(EntityManagerInterface $em)
    {
        $this->em = $em;
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('nom', TextType::class, [
                'label'=>'Nom de la sortie :',
            ])
            ->add('dateHeureDebut', DateTimeType::class,[
                'label'=> 'Date et heure de la sortie :',
                'html5'=> true,
                'widget'=>'single_text',
            ])
            ->add('dateLimiteInscription', DateTimeType::class,[
                'label'=> 'Date limite d\'inscription',
                'html5'=> true,
                'widget'=>'single_text',
            ])
            ->add('nbInscriptionsMax', IntegerType::class, [
                'label'=>'Nombre de places :',
            ])
            ->add('duree', IntegerType::class,[
                'label' => 'Durée (en heure) :',
            ])
            ->add('infosSortie', TextareaType::class,[
                'label'=> 'Description et infos :',
                'required' => false,
            ]);
        // Initialisation VILLE
        // Création d'une sortie
        if ($options['lieuSortie']==null) {
            $builder->add('ville', EntityType::class, [
                // Pas de getters et Setters dans entité Sortie
                'mapped' => false,
                'class' => Ville::class,
                'choice_label' => 'nom',
                'label' => 'Ville :',
                'placeholder' => 'Choisir la ville',

            ]);
        } else {
            // Modification d'une sortie
            $builder->add('ville', EntityType::class, [
                // Pas de getters et Setters dans entité Sortie
                'mapped' => false,
                'class' => Ville::class,
                'choice_label' => 'nom',
                'label' => 'Ville :',
                'data' =>  $options['lieuSortie']->getVille(),
               /* 'choice_attr' => function ($choice){
                return ['data-latitude'=> $choice->getLatitude()];
            },*/

                //'choice_attr'=>
            ]);
        };
        // Initialisation LIEU
        $builder    ->add('lieu',ChoiceType::class,[
                        'label' => 'Lieu :',
                        'placeholder' => 'Choisir une ville',
                        'required' => false,
            ]);

        $builder    ->add('campus',TextType::class,[
                'mapped' => false,
                'label' => 'Campus :',
                'attr' => [
                    'disabled' => true,
                    'value' => $options['data']->getCampus()->getNom(),
                ]
            ])
           /* ->add('rue', TextType::class,[
                'label' => 'Rue :',
            ])
            ->add('codePostal', TextType::class,[
                'label' => 'Code postal :',
            ])
            ->add('latitude', TextType::class,[
                'label' => 'Latitude :',
            ])
            ->add('longitude', TextType::class,[
                'label' => 'longitude :',
            ])*/
        ;

        // $formModifier appelée dans l'eventListener
        $formModifierLieu = function (FormInterface $form, Ville $ville = null){
            $form->add('ville', EntityType::class, [
                'mapped' => false,
                'class' => Ville::class,
                'choice_label' => 'nom',
                'label' => 'Ville :',
                'placeholder' => 'Choisir la ville',
                'data' =>  $ville,
            ]);
            // LES LIEUX EN FONCTION DES VILLES
            // aller chercher les lieux correspondant à la ville
            $lieux = (null === $ville) ? [] : $ville->getLieux();
            // Modification du add Lieu
            $form -> add('lieu', EntityType::class,[
                'class' => Lieu::class,
                'choices' => $lieux,
                'choice_label' => 'nom',
                'placeholder' => 'Lieu (Choisir)',
                'label' => 'Lieu :',
                'choice_attr' => function ($choice){
                    return ['data-latitude'=> $choice->getLatitude()];
                },
            ]);
        };
        // EventListener
        $builder->addEventListener(
            FormEvents::PRE_SET_DATA,
            function (FormEvent $event) use ($formModifierLieu) {
                $lieu = $event->getData()->getLieu();
                $ville = $lieu ? $lieu->getVille() : null;
                $formModifierLieu($event->getForm(), $ville);
            }
        );
        // EventListener
        $builder ->addEventListener(
        // L'évènement sur lequel on s'accroche. On choisi POST-SUBMIT (après envoi du formulaire)
        // à cause d'AJAX lors de la promesse
            FormEvents::PRE_SUBMIT,
            function(FormEvent $event) use ($formModifierLieu){
                // Récupération de la ville sélectionnée
                //$ville = $event->getForm()->getData();
                $ville = $this->em->getRepository(Ville::class)->find($event->getData()['ville']);
                // getForm est lié à $builder et va chercher uniquement $ville.
                // Ajouter getParent() qui va chercher le formulaire entier
                $formModifierLieu($event->getForm(), $ville);
            },
        );
    }

    public function configureOptions(OptionsResolver $resolver)
    {

        $resolver->setDefaults([
            'data_class' => Sortie::class,
            'lieuSortie'=> null,
            'lieuIniVilleList' =>null,
        ]);
    }
}