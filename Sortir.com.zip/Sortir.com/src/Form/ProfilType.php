<?php

namespace App\Form;

use App\Entity\Campus;
use App\Entity\Participant;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\FileType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\File;
use Symfony\Component\Validator\Constraints\Length;

class ProfilType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('pseudo')
            ->add('prenom')
            ->add('nom')
            ->add('telephone')
            ->add('mail', null, [
                'label' => 'Email'
            ])
            ->add('motPasse',PasswordType::class, [
               'mapped'=> false,
                'label' => 'Mot de passe',
                'attr' => [
                    'autocomplet' => 'new-password'],
                'constraints' => [
                    new Length(['min' => 6, 'minMessage' => 'Vous devez entrer au moins {{ limit }} caractères', 'max' => 4096])
                ],
                'required' => false
            ])


            ->add('campus', EntityType::class, [
                'class' => Campus::class,
                'choice_label' => 'nom',
                'disabled' => true
            ])
           // ->add('isAdministrateur')
            //->add('isActif')
            //->add('mesInscriptions')
            // Ajout du champs image
            ->add('image', FileType::class,[
                'mapped'=>false,
                'label'=>false,
               'required' => false,
               'constraints' => [
                    new File([
                        'maxSize' => '1024k',
                        'mimeTypes' => [
                            'image/jpeg',
                        ],
                        'mimeTypesMessage' => 'Merci de télécharger une image de type valide (jpg)',
                    ])
                ],





           ])
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Participant::class,

        ]);
    }
}
