<?php

namespace App\Form;

use App\Entity\Participant;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\Extension\Core\Type\RepeatedType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\Length;
use Symfony\Component\Validator\Constraints\NotBlank;

class ProfilPasswordType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('oldPasse', PasswordType::class, [
                'mapped' => false,
                'label' => 'Mot de passe actuel'
            ])
            ->add('motPasse',RepeatedType::class, [
                'mapped'=> false,
                'type' => PasswordType::class,
                'first_options' => ['label' => 'Mot de Passe'],
                'second_options' => ['label' => 'Confirmation'],
                'invalid_message' => 'Les deux mots de passe doivent être identiques',
                'attr' => [
                    'autocomplet' => 'new-password'],
                'constraints' => [
                    new NotBlank([
                        'message' => 'Saisir le mot de passe pour valider',
                    ]),
                    new Length(['min' => 6, 'minMessage' => 'Vous devez entrer au moins {{ limit }} caractères', 'max' => 4096])
                ],
                'required' => false
            ])
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Participant::class,
        ]);
    }
}
