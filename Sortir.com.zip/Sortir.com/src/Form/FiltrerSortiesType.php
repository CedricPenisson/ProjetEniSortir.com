<?php

namespace App\Form;

use App\Data\FiltrerSorties;
use App\Entity\Campus;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class FiltrerSortiesType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder

            ->add('campus', EntityType::class, [
                'class' => Campus::class,
                'choice_label' => 'nom',
                'label' => 'nom',
            ])
            ->add('recherche', TextType::class, [
                'label' => 'Le nom de la sortie contient',
                'required'=> false,
                'attr'=> [
                    'placeholder' => 'Rechercher'
                ]
            ])
            ->add('dateDebut', DateType::class, [
                'label' => 'Entre',
                'html5' => true,
                'widget' => 'single_text',
                'required'=> false,
            ])
            ->add('dateFin', DateType::class, [
                'label' => 'Et',
                'html5' => true,
                'widget' => 'single_text',
                'required'=> false,
            ])
            ->add('sortiesOrganisees', CheckboxType::class, [
                'label' => 'Sorties dont je suis l\'organisateur/trice',
                'required'=> false
            ])
            ->add('sortiesInscrites', CheckboxType::class, [
                'label' => 'Sorties auxquelles je suis inscrit/e',
                'required'=> false
            ])
            ->add('sortiesNonInscrites', CheckboxType::class, [
                'label' => 'Sorties auxquelles je ne suis pas inscrit/e',
                'required' => false,
            ])
            ->add('sortiesPassees', CheckboxType::class, [
                'label' => 'Sorties passées',
                'required' => false,
            ])
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            // associer à la classe créée
            'data_class' => FiltrerSorties::class,
        ]);
    }


}
