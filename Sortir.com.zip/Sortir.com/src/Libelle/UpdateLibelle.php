<?php

namespace App\Libelle;

use App\Repository\EtatRepository;
use App\Repository\SortieRepository;
use DateTime;
use Doctrine\ORM\EntityManager;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class UpdateLibelle

{
    //Methode pour mettre le libellé OUVERTE
    public function ouvertLibelle(?EntityManagerInterface $entityManager,
                                  ?SortieRepository $sortieRepository, ?EtatRepository $etatRepository)

        // Ajouter dans le constructeur de la classe
    {
        //récuperer toutes les sorties

        $sortiesList = $sortieRepository->findAll();
        $etat = $etatRepository->findOneBy(['libelle' => 'Ouverte']);
        if (!$sortiesList) {
            throw $this->createNotFoundException("lost!!!! bloody Hell!! Pas de sortie pour la Fct ouverte");
        }
        if (!$etat) {
            throw $this->createNotFoundException("lost!!!! bloody Hell!! Pas de sortie pour la Fct ouverte");
        }

        foreach ($sortiesList as $sortie)
            if ($sortie->getInscrits()->count() < $sortie->getNbInscriptionsMax() &&
                $sortie->getDateLimiteInscription() >= new \DateTime('now') &&
                $sortie->getEtat()->getLibelle() == 'Créée') {
                $sortie->setEtat($etat);
                $entityManager->persist($sortie);
                $entityManager->flush();

            }
    }


    //Methode pour mettre le libellé CLOTUREE

    public function clotureLibelle(?EntityManagerInterface $entityManager,
                                   ?SortieRepository $sortieRepository, ?EtatRepository $etatRepository)
    {
        //récuperer toutes les sorties

        $sortiesList = $sortieRepository->findAll();
        $etat = $etatRepository->findOneBy(['libelle' => 'Clôturée']);
       /* if (!$sortiesList) {
            throw $this->createNotFoundException("lost!!!! bloody Hell!! Pas de sortie pour la Fct cloturée");
        }*/
       /* if (!$etat) {
            throw $this->createNotFoundException("lost!!!! bloody Hell!! Pas de sortie pour la Fct cloturée");
        }*/

        foreach ($sortiesList as $sortie) {
            if (($sortie->getInscrits()->count() == $sortie->getNbInscriptionsMax()) ||
                ($sortie->getDateLimiteInscription() < new \DateTime('now')) &&
                ($sortie->getEtat()->getLibelle() == 'Ouverte')) {

                $sortie->setEtat($etat);
                $entityManager->persist($sortie);

            }

        }
        $entityManager->flush();
    }

    //Methode pour mettre le libellé ACTIVITE EN COURS
    public function encoursLibelle(?EntityManagerInterface $entityManager,
                                   ?SortieRepository $sortieRepository, ?EtatRepository $etatRepository)
    {
        //récuperer toutes les sorties

        $sortiesList = $sortieRepository->findAll();
        $etatCloture = $etatRepository->findOneBy(['libelle' => 'Activité en cours']);
        $etatPasse = $etatRepository->findOneBy(['libelle' => 'Passée']);

        if (!$sortiesList) {
            throw $this->createNotFoundException("lost!!!! bloody Hell!! Pas de sortie pour la Fct activité en cours");
        }

        foreach ($sortiesList as $sortie) {
            // Conversion en INT  de la dateHeureDebut
            $dateSortieConvert = $sortie->getDateHeureDebut()->getTimestamp();

            // Duree sortie en INT
            $dureeConvert = $sortie->getDuree() * 3600;

            // Conversion en INT de la Heure/date actuelle
            $dateActuelle = new DateTime('now');
            $dateActuelleConvert = $dateActuelle->getTimestamp();

            if ($sortie->getEtat()->getLibelle() == 'Clôturée' &&
                ($dateActuelleConvert < ($dureeConvert + $dateSortieConvert))) {
                $sortie->setEtat($etatCloture);
                $entityManager->persist($sortie);
                $entityManager->flush();
            }

            if ($sortie->getEtat()->getLibelle() == 'Activité en cours' &&
                ($dateActuelleConvert > ($dureeConvert + $dateSortieConvert))) {
                $sortie->setEtat($etatPasse);
                $entityManager->persist($sortie);
                $entityManager->flush();
            }
    }

    }
}