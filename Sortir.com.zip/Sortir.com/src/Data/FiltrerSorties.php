<?php

namespace App\Data;

use App\Entity\Campus;

class FiltrerSorties
{

    public Campus $campus;

    public ?string $recherche;

    public ?\DateTime $dateDebut;

    public ?\DateTime  $dateFin;

    public ?bool $sortiesOrganisees;

    public ?bool $sortiesInscrites;

    public ?bool $sortiesNonInscrites;

    public ?bool $sortiesPassees;



}