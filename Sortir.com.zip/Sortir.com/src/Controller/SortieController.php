<?php

namespace App\Controller;

use App\Data\FiltrerSorties;
use App\Entity\Etat;
use App\Entity\Participant;
use App\Entity\Sortie;
use App\Form\AnnulationSortieType;
use App\Form\FiltrerSortiesType;
use App\Form\SortieType;
use App\Libelle\UpdateLibelle;
use App\Repository\EtatRepository;
use App\Repository\ParticipantRepository;
use App\Repository\SortieRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

#[Route('/sortie', name: 'sortie_')]
class SortieController extends AbstractController
{
    #[Route('/creer', name: 'creer', methods: ['GET', 'POST', 'PUT'])]
    public function create(Request $request, EntityManagerInterface $entityManager,
                            EtatRepository $etatRepository): Response
    {
        // Récupération du participant connecté
        /** @var Participant  $user
         */
        $user = $this->getUser();
        $sortie = new Sortie();
        $sortie->setOrganisateur($user);
        $sortie->setCampus($user->getCampus());

        // ----------------- FORMULAIRE
        // Création du formulaire
        $sortieForm = $this-> createForm(SortieType::class,$sortie,[

        ]);

        // Application de la requête sur le formulaire
        $sortieForm->handleRequest($request);

        // ------------------- VALIDATION DU FORMULAIRE

        if ($sortieForm->isSubmitted() && $sortieForm->isValid()) {
            // ------------------- LES BOUTONS
            // ENREGISTRER

            if ($request->get('btnEnregistrer')) {
                $etat = $etatRepository->findOneBy(['libelle'=>'Créée']);
                if (!$etat){
                    throw $this->createNotFoundException("L'état 'Créée' n'a pas été trouvé!");
                }
            // PUBLIER
            }else {
                if ($sortie->getInfosSortie() != null) {
                    $etat = $etatRepository->findOneBy(['libelle' => 'Ouverte']);
                    if (!$etat) {
                        throw $this->createNotFoundException("L'état 'Ouverte' n'a pas été trouvé!");
                    }
                    // Sinon l'état ne change pas + Message erreur plublication. Enregistre quand même les autres modifs

                } else {
                    $etat = $etatRepository->findOneBy(['libelle' => 'Créée']);
                    if (!$etat) {
                        throw $this->createNotFoundException("L'état 'Créée' n'a pas été trouvé!");
                    }
                    $this->addFlash('no-success', 'Vous devez renseigner la description de la sortie avant de la publier');
                }
            }

            $sortie->setEtat($etat);

            $entityManager->persist($sortie);
            $entityManager->flush();

            //Message Flash : Succès d'enregistrement
            $this->addFlash('success', 'La sortie a été enregistrée et est dans l\'état '.'"'
                .strtolower($sortie->getEtat()->getLibelle()).'"');

            //Envoi à TWIG avec la sortie
            return $this->redirectToRoute('sortie_modifier', [
                'id'=>$sortie->getId(),
            ]);
        }

            // Envoi à TWIG
            return $this->render('sortie/creer.html.twig', [
                'sortieForm' => $sortieForm->createView(),
                'user' => $user,
            ]);
    }
    #[Route('/modifier/{id<[0-9]+>}', name: 'modifier')]
    public function modifier(Request $request, int $id,SortieRepository $sortieRepository,
                                EtatRepository $etatRepository, EntityManagerInterface $entityManager): Response
    {
        $sortie = $sortieRepository->find($id);
        if (!$sortie) {
            throw $this->createNotFoundException("Sortie inconnue");
        }

        $ville = $sortie->getLieu()->getVille();
        $lieuIniVilleList = $ville->getLieux();

        // ----------------- FORMULAIRE
        // Création du formulaire
        $sortieForm = $this->createForm(SortieType::class, $sortie, [
            'lieuSortie' => $sortie->getLieu(),
            'lieuIniVilleList' => $lieuIniVilleList
        ]);

        // Application de la requête sur le formulaire
        $sortieForm->handleRequest($request);

        if ($sortieForm->isSubmitted() && $sortieForm->isValid()) {

                // ------------------- LES BOUTONS
                // ENREGISTRER
                if ($request->get('btnEnregistrer')) {

                    $etat = $etatRepository->findOneBy(['libelle' => 'Créée']);
                    if (!$etat) {
                        throw $this->createNotFoundException("L'état 'Créée' n'a pas été trouvé!");
                    }
                    // PUBLIER
                } else {

                    // PUBLIER
                    // Si le contenu dans TWIG de infos est renseigné -> état=Ouverte
                    if ($sortie->getInfosSortie() != null) {
                        $etat = $etatRepository->findOneBy(['libelle' => 'Ouverte']);
                        if (!$etat) {
                            throw $this->createNotFoundException("L'état 'Ouverte' n'a pas été trouvé!");
                        }
                        // Sinon l'état ne change pas + Message erreur plublication. Enregistre quand même les autres modifs
                        $sortie->setEtat($etat);
                    } else {
                        $this->addFlash('no-success', 'Vous devez renseigner la description de la sortie avant de la publier');
                    }
                }



                $entityManager->persist($sortie);
                $entityManager->flush();
                //Message Flash : Succès d'enregistrement
                $this->addFlash('success', 'La sortie a été modifiée et est dans l\'état ' .'"'.
                    strtolower($sortie->getEtat()->getLibelle()).'"');
                return $this->redirectToRoute('sortie_accueil');
        }

        //Envoi à Twig
        return $this->render('sortie/gerer.html.twig',[
        'sortieForm' => $sortieForm->createView()
            ,
            'sortie'=>$sortie
        ]);
    }

    #[Route('/accueil', name: 'accueil')]
    public function filtrerSorties( UpdateLibelle $updateLibelle, Request $request, EntityManagerInterface $entityManager,
                                    ParticipantRepository $participantRepository,EtatRepository $etatRepository,
                                    SortieRepository $sortieRepository,
                                    FiltrerSorties $filtrerSorties ): Response
    {
      //Appel de mise a jour des libellés
//        $updateLibelle->ouvertLibelle($entityManager, $sortieRepository, $etatRepository);
        $updateLibelle->clotureLibelle($entityManager, $sortieRepository, $etatRepository);
        $updateLibelle->encoursLibelle($entityManager, $sortieRepository, $etatRepository);

        /**
         * @var Participant $user
         */
        $user = $this->getUser();

        // Récupération du campud de l'utilisateur
        $filtrerSorties->campus=$user->getCampus();

        // Création du formulaire pour filtrer les sorties
        $filtrerSortiesForm  = $this->createForm(FiltrerSortiesType::class, $filtrerSorties );

        // Requête sur le formulaire
        $filtrerSortiesForm ->handleRequest($request);

        // Application des requêtes
        $filtresResult = $sortieRepository->findFiltresSorties($filtrerSorties, $user);

        //Récupération de l'heure actuelle
        $dateActuelle = new \DateTime('now');

        return $this->render('sortie/accueil.html.twig', [
            'filtrerSortiesForm' => $filtrerSortiesForm->createView(),
             'sortiesResult' => $filtresResult,
            'dateActuelle' => $dateActuelle
        ]);


    }

    #[Route("/details/{id}", name: "details")]
    public function details(int $id, SortieRepository $sortieRepository, ParticipantRepository $participantRepository) : Response
    {
       $sortie = $sortieRepository->find($id);
        if(!$sortie) {
            throw $this->createNotFoundException('Pas de sortie');
        }
        return $this->render('sortie/details.html.twig', [
            "sortie" => $sortie,
        ]);
    }

    #[Route("/annuler/{id}", name: "annuler")]
    public function annulerSortie(int $id, SortieRepository $sortieRepository, EntityManagerInterface $entityManager,
                                  ParticipantRepository $participantRepository,
                                  Request $request, EtatRepository $etatRepository,
                                    AnnulationSortieType $annulationSortieType) : Response
{

    // Récupération des données dont on aura besoin dans la fonction
    $user = $this->getUser();
    $sortie = $sortieRepository->find($id);
    $sortie->setInfosSortie('');
    $dateNow = New \DateTime('now');
    $dateCloture = $sortie->getDateHeureDebut();

    // Création du formulaire pour filtrer les sorties
    $annulationSortieType = $this-> createForm(AnnulationSortieType::class, $sortie);

    // Requête sur le formulaire
    $annulationSortieType->handleRequest($request);

    // Condition pour autoriser seulement les organisateurs
    if($user == $sortie->getOrganisateur()){
        // Condition pour interdire l'annulation si la date de clôture est dépassée
        if ($dateNow < $dateCloture) {
            if ($annulationSortieType->isSubmitted() && $annulationSortieType->isValid()) {
                // Récupération du libéllé Annulée
                $etat = $etatRepository->findOneBy(['libelle' => 'Annulée']);
                // Passage de l'état Annulée dans la sortie
                $sortie->setEtat(($etat));
                $entityManager->persist($sortie);
                $entityManager->flush();

                // Envoi d'un message de succès
                $this->addFlash('success', 'La sortie a été annulée avec succès!');
                return $this->redirectToRoute('sortie_accueil');
            }
        }else{                  // Envoi d'un message d'échec si la date de clôture est passée
            $this->addFlash('no-success', 'Vous ne pouvez pas annuler une sortie commencée.');
        }
    } else{                     // Envoi d'un message d'échec si l'utilisateur n'est pas l'organisateur
        $this->createNotFoundException('Vous n\'avez pas les droits pour annuler une sortie.');
    }

    return $this->render('sortie/annuler.html.twig',[
        'sortie' => $sortie,
        'annulationSortieForm' => $annulationSortieType->createView(),
        ]);
}

}
