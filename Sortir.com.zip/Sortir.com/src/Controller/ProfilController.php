<?php

namespace App\Controller;

use App\Entity\Participant;
use App\Form\ProfilPasswordType;
use App\Form\ProfilType;
use App\Repository\ParticipantRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\File\Exception\FileException;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Core\Encoder\UserPasswordEncoderInterface;


#[Route('/profil', name:'profil_')]
class ProfilController extends AbstractController
{
    #[Route('/modifier', name: 'modifier', methods: ['GET', 'PUT'])]
    public function modifier(Request $request, EntityManagerInterface $entityManager) : Response {
        //Récupérer l'utilisateur connecté
        /**
         * @var Participant $profil
         */
        $profil = $this->getUser();

        //Création du formulaire
        $profilForm = $this->createForm(ProfilType::class, $profil, [
            'method' => 'PUT'
        ]);

        //Traitement formulaire
        $profilForm->handleRequest($request);

        if ($profilForm->isSubmitted() && $profilForm->isValid()){


            //Verifier si le bouton est enregistrer ou annuler
            if ($request->get('btnEnregistrer')) {

                // TRAITEMENT DE LA PHOTO DE PROFIL
                /**
                 * @var UploadedFile $imageDownloaded
                 */
                $imageDownloaded = $profilForm->get('image')->getData();
                dump($imageDownloaded);
                // Si un fichier est renseigné
                if ($imageDownloaded){
                    $originalFilename = pathinfo($imageDownloaded->getClientOriginalName(), PATHINFO_FILENAME);

                    $newFileName = $profil->getNom().'-'.uniqid().'.'.$imageDownloaded->guessExtension();


                }

                // Envoyer le fichier dans : rep déclaré dans services.yaml
                try {
                    $imageDownloaded->move(
                        $this->getParameter('img_participants_directory'),
                        $newFileName
                    );
                    $profil->setPhoto($newFileName);
                    $entityManager->persist($profil);
                }catch (FileException $e){
                    // Message Flash erreur
                    $this->addFlash('no-success', 'Impossible de charger l\'image : '.$e);
                }

                //Password du profil dans BDD
                $profilPassword = $profil->getPassword();

                //Password taper dans le formulaire
                $password = $profilForm->get('motPasse')->getData();

                //Vérifier que le mot de passe est le même que celui taper dans le formulaire
                if (password_verify($password, $profilPassword) != false) {
                    //Valider les données
                    $entityManager->flush();
                    //Créer un message flashe (détruit automatiquement)
                    $this->addFlash('success', 'Profil modifié');
                    return $this->redirectToRoute('profil_modifier');
                } else {
                    //Créer un message flashe (détruit automatiquement)
                    $this->addFlash('no-success', 'Mot de passe est incorrect');
                }
            } elseif ($request->get('btnAnnuler')) {
                return $this->redirectToRoute('main_home');
            }
        }
        //Afficher dans le twig les informations du profil
        return $this->render('participant/profil.html.twig', [
            'profilForm' => $profilForm->createView(),
            'myProfil'=> $profil,
        ]);
    }

    //Afficher toute la liste des utilisateurs
    #[Route('/afficher', name: 'afficher')]
    public function afficher(ParticipantRepository $participantRepository) : Response {
        //Requête pour afficher la liste complète des utilisateurs de la BDD
        $profils = $participantRepository->findAll();
        if (!$profils){
            throw $this->createNotFoundException("Il n'y a pas d'utilisateur");
        }

        return $this->render('participant/afficher.html.twig', [
            'listProfil' => $profils
        ]);
    }

    // /{id<[0-9]+>} Afficher les détails d'un profil
    #[Route('/detail/{id<[0-9]+>}', name: 'detail')]
    public function detail(int $id,ParticipantRepository $participantRepository): Response {
        //Requête pour afficher l'utilisateur en fonction de son id
        $profil = $participantRepository->find($id);
        if (!$profil){
            throw $this->createNotFoundException("L'utilisateur n'existe pas!");
        }
        return $this->render('participant/details.html.twig', [
            'myProfil' => $profil
        ]);
    }

    #[Route('/changer-mot-de-passe', name: 'changerPassword', methods: ['GET', 'PUT'])]
    public function changerPassword(Request $request, EntityManagerInterface $entityManager, UserPasswordEncoderInterface $passwordEncoder){
        //Récupérer l'utilisateur connecté
             $profil = $this->getUser();
        //Récupérer son mot de passe (celui de la BDD)
             $oldPassword = $profil->getPassword();
        //Créer le formulaire
            $profilForm = $this->createForm(ProfilPasswordType::class,$profil, [
            'method' => 'PUT'
            ]);
        //Traitement formulaire
            $profilForm->handleRequest($request);
        //Password taper dans le formulaire
            $oldPasswordFormulaire = $profilForm->get('oldPasse')->getData();

        if ($profilForm->isSubmitted() && $profilForm->isValid()) {
            if ($request->get('btnEnregistrer')) {
                //Vérifie que le mot de passe actuel est le même
                if (password_verify($oldPasswordFormulaire, $oldPassword) != true){
                    //Créer un message flashe (détruit automatiquement)
                    $this->addFlash('no-success', 'Mot de passe actuel non valide');
                } else {
                    //Nouveau mot de passe et encodage du nouveau mot de passe
                    $newPassword = $profilForm->get('motPasse')->getData();
                    if (password_verify($newPassword, $oldPassword) != true) {
                        //Encoder le nouveau mot de passe
                        $encoderPassword = $passwordEncoder->encodePassword($profil, $newPassword);
                        $profil->setPassword($encoderPassword);
                        //Valider les données
                        $entityManager->flush();
                        //Créer un message flashe (détruit automatiquement)
                        $this->addFlash('success', 'Mot de passe est changé');
                        return $this->redirectToRoute('main_home');
                    }else {
                        //Créer un message flashe (détruit automatiquement)
                        $this->addFlash('no-success', 'Le mot de passe doit être différent de l\'actuel');
                    }
                }
            }
        }
        //Afficher dans le twig les informations du profil
        return $this->render('participant/changerPassword.html.twig', [
            'profilForm' => $profilForm->createView()
        ]);
    }
}
