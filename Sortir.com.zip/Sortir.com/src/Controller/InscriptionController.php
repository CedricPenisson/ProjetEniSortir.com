<?php

namespace App\Controller;

use App\Repository\SortieRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class InscriptionController extends AbstractController
{
    #[Route('/inscription', name: 'inscription')]
    public function index(): Response
    {
        return $this->render('inscription/index.html.twig', [
            'controller_name' => 'InscriptionController',
        ]);
    }

    #[Route('/inscription/{id}', name: 'ajouterSortie')]
    public function ajouterSortie(int $id, EntityManagerInterface $entityManager, SortieRepository $sortieRepository) : Response
    {
        $user = $this->getUser(); //utilisateur connecté
        $sortie = $sortieRepository->find($id); //sortie a ajouter

        // verifier si sortie est ouverte (libelle de l'Etat)  et date de cloture pas depassee
       if ($sortie->getEtat()->getLibelle() == 'Ouverte' && $sortie->getDateLimiteInscription()>new \DateTime('now')
           && $sortie->getInscrits()->count()<=$sortie->getNbInscriptionsMax()){
           $sortie->addInscrit($user);
           $entityManager->persist($sortie);
           $entityManager->flush();
       }else {
           return $this->redirectToRoute('sortie_accueil');
       }

        //Redirection vers le détail de la sortie avec la liste des inscrits
        return $this->redirectToRoute('sortie_details', [
            'id' => $sortie->getId(),
        ]);
    }

    //Méthode pour retirer le participant de la liste d'une sortie = de la sortie
    #[Route('/desister/{id}', name: 'desister')]
    public function desister(int $id, SortieRepository $sortieRepository, EntityManagerInterface $entityManager){
        //utilisateur connecté
        $user = $this->getUser();

        //Verifier la sortie dans la requete
        $sortie = $sortieRepository->find($id);

        //On retire l'user de la sortie ==> méthode removeInscrit(participant) dans la classe sortie.php (entité)
        $sortie->removeInscrit($user);

        //Enregistre la modification dans la BDD
        $entityManager->flush();

        //Redirection vers le détail de la sortie avec la liste des inscrits
        return $this->redirectToRoute('sortie_accueil', [
            'id' => $sortie->getId(),
        ]);

    }

}
